## MIRA-DB INSTALL

``` npm install mira-db ```

--- 

  EXAMPLE DATABASE DIR => "./data/"

