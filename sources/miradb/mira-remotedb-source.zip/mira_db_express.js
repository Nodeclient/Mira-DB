// MIRA-DB EXPRESS REMOTE DATABASE
var bodyParser = require("body-parser");
var express = require('express');
var mira = require('mira-db');
var UserData = require('mira-db/userdata');
var app = express();

var USR_PERM = {};
// SET YOUR STORAGE FOLDER
var DB_DIR = "./data";

app.use(express.static('public'));
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
app.use(function (req, res, next) { next(); });

app.get('/', function (req, res, next) {
    res.sendFile(process.cwd() + '/public/index.html');
});

app.post('/query', function (req, res, next) {
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS, PUT');
    res.setHeader('Access-Control-Allow-Headers', 'X-Requested-With,content-type');
    res.setHeader('Access-Control-Allow-Credentials', true);

    var DB_NAME = req.body["db"];
    var DB_USER = req.body["user"];
    var DB_PASS = req.body["pass"];
    var DB_QUERY = req.body["query"];
    var expressDB = new mira(DB_DIR, "UTF-8");

    var LOGIN_DATA = UserData.LoadLoginData("user.conf");
    if (LOGIN_DATA[0]) {
        var result = UserData.Login(DB_USER, DB_PASS, LOGIN_DATA);
        var USR_PERM = UserData.LoadPermsData(result["perm"] + ".perm");
        if (result) {
            if (result["db"] == "*") {
                var DB_RESULT = expressDB.Query(DB_QUERY, DB_NAME, USR_PERM);
                res.send(200,DB_RESULT);
            } else {
                var DB_RESULT = expressDB.Query(DB_QUERY, result["db"], USR_PERM);
                res.send(200,DB_RESULT);
            }
        } else {
            res.send(401,[false, "LOGIN_ERROR", "INVALID USERNAME OR PASSWORD", 0]);
        }
    } else {
        res.send(500,[false, "SERVER_ERROR", "INVALID CONF FILE", 100]);
    }
});
// YOU CAN CHANGE THE PORT
var server = app.listen(8123);
console.log("MIRA DB RUNNING PORT:8123")