    var bodyParser = require("body-parser");
    var express = require('express');
    var mira = require('mira-db');
    var UserData = require('mira-db/userdata');
    var app = express();

    var USR_PERM_TEMP = { SELECT: true, ADD: true, UPDATE: true, RENAME: true, DROP: true, DELETE: true, CREATE: true, LIST: true };
    var DB_DIR = "./data";

    app.use(express.static('public'));
    app.use(bodyParser.json());
    app.use(bodyParser.urlencoded({ extended: true }));
    app.use(function (req, res, next) { next(); });


    app.get('/', function (req, res, next) {
        var options = { root: process.cwd() + '/public/', dotfiles: 'deny' };
        var fileName = "login.html";
        res.sendFile(fileName, options, function (err) {
            if (err) {
                res.status(err.status).end();
            }
        });
    });

    app.post('/query', function (req, res, next) {

        res.setHeader('Access-Control-Allow-Origin', '*');
        res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS, PUT, PATCH, DELETE');
        res.setHeader('Access-Control-Allow-Headers', 'X-Requested-With,content-type');
        res.setHeader('Access-Control-Allow-Credentials', true);

        var DB_NAME = req.body["db"];
        var DB_USER = req.body["user"];
        var DB_PASS = req.body["pass"];
        var DB_QUERY = req.body["query"];
        var expressDB = new mira(DB_DIR, "UTF-8");


        var LOGIN_DATA = UserData.LoadLoginData("user.conf");
        if (LOGIN_DATA[0]) {
            var result = UserData.Login(DB_USER, DB_PASS, LOGIN_DATA);
            var USR_PERM = UserData.LoadPermsData(result["perm"] + ".perm");
            if (result) {
                var DB_RESULT = expressDB.Query(DB_QUERY, DB_NAME, USR_PERM);  
                res.send(200, DB_RESULT );
            } else {
                res.send(401, [false, "LOGIN_ERROR", "INVALID USERNAME OR PASSWORD", 0] );
            }
        } else {
            res.send(500, [false, "SERVER_ERROR", "INVALID CONF FILE", 100]);
        }

        // console.log( req.body["user"] , req.body["pass"] , req.body["db"], req.body["query"]);
        // res.status(500).send('Error while performing Query.');
        // var err = new Error('You must be logged in to view this page.');
        // err.status = 401;
        // return next(err.message);
        // res.status(500).send('Something broke!');
    });

    app.listen(8123);
    console.log("Mira-DB Server [localhost]:8123");
    