
//install request plugin : "npm i request -g" 
//download Connector : "miradb.nodejs.1.0.0.zip"

const MiraDB = require("./miradb.nodejs.1.0.0");

var db = new MiraDB("root","","http://localhost:8123/query","test");   
    db.query("select table test",function(data,err){
        console.log(data);
});