<?php
    // DOWNLOAD CONNECTOR -> miradb.php.1.0.0.zip
    include 'miradb_php_connector.php';
        $db = new MiraDB("root","","http://localhost:8123/query","test");
            echo  $db->query("select table person");
?>