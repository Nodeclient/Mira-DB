package org.mira.database;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.Reader;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;


public class db {
	public String user = null;
	public String password = null;
	public String host = null;
	public String database = null;
	 
	public String Query(String Query) {
		try {		
				return db(Query);
		} catch (IOException e) {
				return e.getMessage();
		} 
	}
	
	private String db(String Syntax) throws IOException {
			String urlParameters  = "user="+user+"&pass="+password+"&db="+database+"&query="+Syntax;
			 byte[] postData       = urlParameters.getBytes( StandardCharsets.UTF_8 );
			 int    postDataLength = postData.length;
			 String request        = host;
			 URL    url            = new URL( request );
			 HttpURLConnection conn= (HttpURLConnection) url.openConnection();           
			 conn.setDoOutput( true );
			 conn.setInstanceFollowRedirects( false );
			 conn.setRequestMethod( "POST" );
			 conn.setRequestProperty( "Content-Type", "application/x-www-form-urlencoded"); 
			 conn.setRequestProperty( "charset", "utf-8");
			 conn.setRequestProperty( "Content-Length", Integer.toString( postDataLength ));
			 conn.setUseCaches( false );
				
			 try( DataOutputStream wr = new DataOutputStream( conn.getOutputStream())) {
				    wr.write( postData );
			 }
	
		     if (conn.getResponseCode() == 401) {
		    	 return "LOGIN_ERRROR";
			 } else if (conn.getResponseCode() == 500) {
				 return "SERVER_ERRROR";
			 } else {
				  Reader in = new BufferedReader(new InputStreamReader(conn.getInputStream(), "UTF-8"));
		          StringBuilder sb = new StringBuilder();
			      for (int c; (c = in.read()) >= 0;) sb.append((char)c);
			      String response = sb.toString();
				 return response;
			 }				 	
	}

}
