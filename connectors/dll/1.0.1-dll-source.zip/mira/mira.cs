﻿using System;
using System.Text;
using System.Net;
using System.Collections.Specialized;
using System.Collections;

namespace MIRA
{
    public class database
    {
        // EXPRESS SERVER CONNECTOR
        public string Server;
        public string User;
        public string Password;
        public string Database;

        // IMPORT REFERANCE -> "System.Web.Extensions"
        public ArrayList row (string jsonString)
        {
            ArrayList result = new System.Web.Script.Serialization.JavaScriptSerializer().Deserialize<ArrayList>(jsonString);
            return result;
        }

        //CONNECTOR
        public string Query(string Query_String) {
            try
            {
                var client = new WebClient();
                var values = new NameValueCollection();
                values["user"] = User;
                values["pass"] = Password;
                values["db"] = Database;
                values["query"] = Query_String;
                var response = client.UploadValues(Server, values);
                var responseString = Encoding.Default.GetString(response);
                    return responseString;
            }
            catch (Exception ex) {
                return "Connection Error!";
            }

        }

    }
}
